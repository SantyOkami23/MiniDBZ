#!usr/bin/python
import pygame


class Level:
    def __init__(self):
        pass
